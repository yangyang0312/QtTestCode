#include "MyGraphicsProxyWidget.h"
#include <QDebug>

MyGraphicsProxyWidget::MyGraphicsProxyWidget(QGraphicsProxyWidget * view,QObject *parent)
    : QObject(parent)
{
    this->view = view;
}

void MyGraphicsProxyWidget::changeRotate(int rotate)
{
    qDebug()<<view->size()<<view->pos()<<view->mapToParent(0,0)<<view->mapToScene(0,0);
    view->setRotation(rotate);
    static int rotateCount = 1;
    if(rotateCount == 1){
        view->moveBy(720,-35);
    }else if(rotateCount == 2){
        view->moveBy(70,755);
    }else if(rotateCount == 3){
        view->moveBy(-790,35);
    }else{
        view->moveBy(0,-755);
    }
    if(rotateCount == 4)
        rotateCount = 0;
    ++rotateCount;
}
