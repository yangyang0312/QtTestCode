#ifndef MANAGER_H
#define MANAGER_H

#include <QObject>
#include <QGraphicsScene>
#include <QGraphicsView>
#include "MyGraphicsProxyWidget.h"
#include "mainwindow.h"


class Manager : public QObject
{
    Q_OBJECT
public:
    explicit Manager(QObject *parent = 0);

public slots:
    void changeRotate(int rotate);
private:
    MainWindow * widget;
    QGraphicsScene * scene;
    QGraphicsProxyWidget * w;
    MyGraphicsProxyWidget * myView;
    QGraphicsView * view;
};

#endif // MANAGER_H
