#include "Manager.h"
#include <QDebug>
#include <QScrollBar>

Manager::Manager(QObject *parent) : QObject(parent)
{
    widget = new MainWindow;
    scene = new QGraphicsScene;
    scene->setSceneRect(widget->geometry());
    w = scene->addWidget(widget);
    myView = new MyGraphicsProxyWidget(w);
    //w->setRotation(180);
    view = new QGraphicsView(scene);
    view->setWindowFlags(Qt::FramelessWindowHint);
    view->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    view->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    view->resize(widget->size());
    //view->setTransformationAnchor(QGraphicsView::NoAnchor);
    QObject::connect(widget,SIGNAL(changeRotate(int)),this,SLOT(changeRotate(int)));
    QObject::connect(widget,SIGNAL(changeRotate(int)),myView,SLOT(changeRotate(int)));
    //myView->moveBy(-308,-408);
    view->move(0,0);
    view->setFrameStyle(QFrame::NoFrame);
    view->show();
    //changeRotate(1);
    qDebug()<<view->pos()<<view->geometry();
}

void Manager::changeRotate(int)
{
    static int rotateCount = 1;
    if(rotateCount == 1 || rotateCount == 3){
        view->resize(720,790);
    }else{
        view->resize(790,720);
    }
    if(rotateCount == 4)
        rotateCount = 0;
    ++rotateCount;
}
